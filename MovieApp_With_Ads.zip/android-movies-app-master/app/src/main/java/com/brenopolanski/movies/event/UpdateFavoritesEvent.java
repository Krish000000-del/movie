package com.brenopolanski.movies.event;

public class UpdateFavoritesEvent {

    public UpdateFavoritesEvent() {

    }
}
